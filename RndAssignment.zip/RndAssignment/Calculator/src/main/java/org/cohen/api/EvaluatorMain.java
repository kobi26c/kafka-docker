package org.cohen.api;

import org.cohen.expressions_parser.parser.handler.ExpressionHandlerFactory;
import org.cohen.expressions_parser.parser.handler.ExpressionsHandler;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class EvaluatorMain {

    public static <T extends Number> Map<String, T> evaluateExpressions(List<String> expressions, Class<T> type) {
        ExpressionsHandler<T> handler = ExpressionHandlerFactory.getHandler(type);

        expressions.forEach(handler::addExpression);

        return handler.getVariables();
    }

    public static Map<String, Integer> evaluateExpressions(File file) throws IOException {
        return evaluateExpressions(Files.readAllLines(file.toPath()));
    }

    public static Map<String, Integer> evaluateExpressions(List<String> expressions) {
        return evaluateExpressions(expressions, Integer.class);
    }

    public static void main(String[] args) {
//        System.out.println(evaluateExpressions(Arrays.asList("i = 0",
//                "j = ++i",
//                "x = i++ + 5",
//                "y = 5 + 3 * 10",
//                "i += y")).toString());
//
//        int i = 0;
//        int x = i++ + i++ + i++;
//        System.out.println(evaluateExpressions(Arrays.asList("i =0", "x = i++ + i++ + i++")).toString());


        int i = 0;
        i = ++i+2+i++ + ++i;
        System.out.println(i);
        System.out.println(evaluateExpressions(Arrays.asList("i = 0", "i++j")).toString());


        int x = 7 / 3 * 2 / 2 * 2;
        System.out.println(x);
        System.out.println(evaluateExpressions(Arrays.asList("x = 7 / 3 * 2 / 2 * 2")).toString());

    }

}
