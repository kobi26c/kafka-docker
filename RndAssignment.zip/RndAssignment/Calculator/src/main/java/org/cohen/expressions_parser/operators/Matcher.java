package org.cohen.expressions_parser.operators;

public interface Matcher {

    boolean matches(char ch);
}
