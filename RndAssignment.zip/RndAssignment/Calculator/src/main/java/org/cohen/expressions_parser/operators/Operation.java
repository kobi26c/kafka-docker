package org.cohen.expressions_parser.operators;

public interface Operation<T extends Number> extends Matcher {
    T calculate(T first, T second);
}
