package org.cohen.expressions_parser.operators;

public enum OperationType {
    PRODUCT,
    FACTOR;
}
