package org.cohen.expressions_parser.operators;

import java.util.Arrays;
import java.util.List;

public enum Operator implements Operation<Integer> {
    PLUS('+', OperationType.FACTOR) {
        @Override
        public Integer calculate(Integer first, Integer second) {
            return first + second;
        }
    },
    MINUS('-', OperationType.FACTOR)  {
        @Override
        public Integer calculate(Integer first, Integer second) {
            return first - second;
        }
    },
    MULTIPLICATION('*', OperationType.PRODUCT)  {
        @Override
        public Integer calculate(Integer first, Integer second) {
            return first * second;
        }
    },
    DIVISION('/', OperationType.PRODUCT)  {
        @Override
        public Integer calculate(Integer first, Integer second) {
            return first / second;
        }
    };

    private char symbol;
    private OperationType type;
    private static List<Operator> values = Arrays.asList(values());

    Operator(char symbol, OperationType type) {
        this.symbol = symbol;
        this.type = type;
    }

    @Override
    public boolean matches(char ch) {
        return symbol == ch;
    }

    public static List<Operator> getValues() {
        return values;
    }

    public OperationType getType() {
        return type;
    }
}
