package org.cohen.expressions_parser.operators;

import org.cohen.expressions_parser.UnaryOperation;
import org.cohen.expressions_parser.UnaryOperator;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Operators {

    public static List<Operation<Integer>> getOperationsByType(OperationType operationType) {
        return Operator.getValues().stream().
                filter(operation -> operation.getType().equals(operationType)).
                collect(Collectors.toList());
    }

    public static List<UnaryOperation<Integer>> getUnaryOperations() {
        return Collections.unmodifiableList(UnaryOperator.getValues());
    }
}
