package org.cohen.expressions_parser.operators;

public interface UnaryOperation<T extends Number> extends Matcher {
    T calculate(T value);
}
