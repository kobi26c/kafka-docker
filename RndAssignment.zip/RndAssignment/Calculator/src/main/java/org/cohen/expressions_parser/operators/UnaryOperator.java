package org.cohen.expressions_parser.operators;

import java.util.Arrays;
import java.util.List;

/**
 * Default implementation for Integer
 */
public enum UnaryOperator implements UnaryOperation<Integer> {
    UNARY_PLUS('+') {
        @Override
        public Integer calculate(Integer value) {
            return value;
        }
    },
    UNARY_MINUS('-')  {
        @Override
        public Integer calculate(Integer value) {
            return -value;
        }
    };

    private char symbol;
    private static List<UnaryOperator> values = Arrays.asList(values());

    UnaryOperator(char symbol) {
        this.symbol = symbol;
    }

    @Override
    public boolean matches(char ch) {
        return symbol == ch;
    }

    public static List<UnaryOperator> getValues() {
        return values;
    }
}
