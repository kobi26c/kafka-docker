package org.cohen.expressions_parser.parser;

import org.cohen.expressions_parser.operators.Operation;
import org.cohen.expressions_parser.operators.OperationType;
import org.cohen.expressions_parser.operators.UnaryOperation;

import java.util.List;
import java.util.function.Supplier;

/**
 * A Recursive descent parser
 */
public abstract class AbstractExpressionEvaluator<T extends Number> implements ExpressionEvaluator<T> {

    private int position = -1;
    private String currentExpression;
    private char currentChar;
    
    protected AbstractExpressionEvaluator() { }
    
    protected abstract T fromString(String number);
    
    protected abstract boolean isValidDigitChar(char ch);

    protected abstract List<Operation<T>> getOperations(OperationType type);

    protected abstract List<UnaryOperation<T>> getUnaryOperations();


    //Grammar:
    //Expression = Term | Expression `+` Term | Expression `-` Term
    //Term = Factor | Term `*` Factor | Term `/` Factor
    //Factor = `+` Factor | `-` Factor | `(` Expression `)` | Number

    @Override
    public synchronized T evaluate(String expression) {
        initialState(expression);

        nextChar();
        T x = parseExpression();
        if (position < expression.length()) {
            exception();
        }

        return x;
    }

    private void initialState(String expression) {
        position = -1;
        this.currentExpression = expression;
    }

    private void nextChar() {
        currentChar= (++position < currentExpression.length()) ? currentExpression.charAt(position) : (char)-1;
    }

    private void eatEmpty() {
        while (currentChar == ' ') {
            nextChar();
        }
    }

    private boolean eat(int charToEat) {
        eatEmpty();
        if (currentChar == charToEat) {
            nextChar();
            return true;
        }
        return false;
    }

    private T parseExpression() {
        T x = parseTerm();
        return parseCommon(x, () -> getOperations(OperationType.FACTOR), this::parseTerm);
    }

    private T parseTerm() {
        T x = parseFactor();
        return parseCommon(x, () -> getOperations(OperationType.PRODUCT), this::parseFactor);

    }

    private T parseCommon(T x, Supplier<List<Operation<T>>> operations, VoidFunction<T> onCalc) {
        for (;;) {
            eatEmpty();
            boolean foundMatch = false;
            for(Operation<T> operation : operations.get()) {
                if(operation.matches(currentChar)) {
                    nextChar();
                    foundMatch = true;
                    x = operation.calculate(x, onCalc.apply());
                }
            }
            if(!foundMatch) {
                return x;
            }
        }
    }

    private T parseFactor() {
        eatEmpty();
        for(UnaryOperation<T> unaryOperation : getUnaryOperations()) {
            if(unaryOperation.matches(currentChar)) {
                nextChar();
                return unaryOperation.calculate(parseFactor());
            }
        }


        T x;
        int startPos = position;
        //Handle parentheses
        if (eat('(')) {
            x = parseExpression();
            eat(')');
        } else if (isValidDigitChar(currentChar)) { // numbers
            while (isValidDigitChar(currentChar)) {
                nextChar();
            }
            x = fromString(currentExpression.substring(startPos, this.position));
        } else {
            throw new ParserException(getExceptionMessage());
        }
//        if (eat('^')) {
//            x = Math.pow(x, parseFactor()); // exponentiation
//        }

        return x;
    }


    private void exception() {
        throw new ParserException(getExceptionMessage());
    }

    private String getExceptionMessage() {
        return "Unexpected: " + currentChar + " in expression: " + currentExpression;
    }


    @FunctionalInterface
    public interface VoidFunction<T> {
        T apply();
    }


}
