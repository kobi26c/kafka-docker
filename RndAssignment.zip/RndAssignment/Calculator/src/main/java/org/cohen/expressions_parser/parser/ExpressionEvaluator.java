package org.cohen.expressions_parser.parser;

/**
 * interface of an expression evaluator that returns a number (Integer, Double, etc..)
 *
 * @author Kobi Cohen
 */
public interface ExpressionEvaluator<T extends Number> {

    T evaluate(String expression);

}
