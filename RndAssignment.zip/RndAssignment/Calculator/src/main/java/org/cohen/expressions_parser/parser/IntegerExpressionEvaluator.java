package org.cohen.expressions_parser.parser;

import org.cohen.expressions_parser.operators.Operation;
import org.cohen.expressions_parser.operators.OperationType;
import org.cohen.expressions_parser.operators.Operators;
import org.cohen.expressions_parser.operators.UnaryOperation;

import java.util.List;

public class IntegerExpressionEvaluator extends AbstractExpressionEvaluator<Integer> {


    public IntegerExpressionEvaluator() {
        super();
    }

    @Override
    protected Integer fromString(String number) {
        return Integer.valueOf(number);
    }

    @Override
    protected boolean isValidDigitChar(char ch) {
        return Character.isDigit(ch);
    }

    @Override
    protected List<Operation<Integer>> getOperations(OperationType type) {
        return Operators.getOperationsByType(type);
    }

    @Override
    protected List<UnaryOperation<Integer>> getUnaryOperations() {
        return Operators.getUnaryOperations();
    }
}
