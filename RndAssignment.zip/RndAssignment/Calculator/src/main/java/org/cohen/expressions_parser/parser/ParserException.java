package org.cohen.expressions_parser.parser;

public class ParserException extends RuntimeException {

    public ParserException(String message) {
        super(message);
    }
}
