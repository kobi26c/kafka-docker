package org.cohen.expressions_parser.parser.handler;

import org.cohen.expressions_parser.parser.IntegerExpressionEvaluator;
import org.cohen.expressions_parser.parser.ParserException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AssignmentConverter implements ExpressionConverter {

    private static int tempCount = 0;

    AssignmentConverter() {

    }

    @Override
    public <T extends Number> List<String> convertExpression(String expression, ExpressionContext<T> context) {
        List<String> newExpressions = new ArrayList<>();

        //Find all [Variable]++ (post and pre) and replace with temp expression
        String updatedExpression = expression;

        validateIncrementDecrement(updatedExpression);


        while(updatedExpression.contains("++") || newExpressions.contains("--")) {

            //In order to not get into infinite loop - we will check that we found something each iteration
            boolean found = false;
            for(IncrementDecrementType type : IncrementDecrementType.values()) {
                Matcher matcher = type.pattern.matcher(updatedExpression);
                if(matcher.find()) {
                    found = true;
                    String group = matcher.group();
                    String variableName = IncrementDecrementConverter.getVariableName(type.increment, group).trim();
                    String tempVariable = generateTempVariableName(variableName);
                    context.addTempVariable(tempVariable);
                    String tempExpression = String.format("%s=%s", tempVariable, variableName);
                    String assignmentExpression = IncrementDecrementConverter.createNewExpression(type.increment, variableName);
                    if(type.post) {
                        newExpressions.add(tempExpression);
                        newExpressions.add(assignmentExpression);
                    } else {
                        newExpressions.add(assignmentExpression);
                        newExpressions.add(tempExpression);
                    }

                    updatedExpression = matcher.replaceFirst(tempVariable);
                }

            }

            if(!found) {
                throw new ParserException("Cannot parse expression: " + expression + ". it has unmatched ++ or --");
            }
        }


        //Converts and add variable - if we have special equals or not
        for(String operator : Arrays.asList("*", "/", "+", "-", "")) {
            String operatorEquals = operator + "=";
            if(updatedExpression.contains(operatorEquals)) {
                String[] variableAndExpression = updatedExpression.split(Pattern.quote(operatorEquals));
                String variableName = variableAndExpression[0].trim();
                String newExpression;
                if(operator.isEmpty()) {
                    newExpression = updatedExpression;
                } else {
                    newExpression = (String.format("%s=%s%s(%s)", variableName, variableName, operator, variableAndExpression[1]));
                }
                context.addVariable(variableName);
                newExpressions.add(newExpression);
                break;
            }
        }

        return newExpressions;

    }

    /**
     * If expression has 3 or more pluses/minuses (w/o spaces) the expression is not valid
     */
    private void validateIncrementDecrement(String expression) {
        Pattern multiPlus = Pattern.compile("\\+\\+(\\+)+");
        Pattern multiMinus = Pattern.compile("\\-\\-(\\-)+");

        for(Pattern pattern : Arrays.asList(multiPlus, multiMinus)) {
            Matcher matcher = pattern.matcher(expression);
            if(matcher.find()) {
                throw new ParserException(String.format("%s is invalid in expression: %s", matcher.group(), expression));
            }
        }

    }

//    private String addSpacesToExpressionIfNeeded(String updatedExpression) {
//        //We are validating that there is a space after ++ or -- because syntax like the following is not valid:
//        //x = i+++5 (should be i++ +5) - this line should handle the case we have -- or ++ at the end of the expression
//        //We have some cases that it's valid without space and we need to manipulate them, For example:
//        //x=++i or x=i++ (in the start or end)
//        if(updatedExpression.endsWith("++") || updatedExpression.endsWith("--")) {
//            updatedExpression = updatedExpression.concat(" ");
//        }
//
//        //We are
//        if(updatedExpression.contains("=++")) {
//            updatedExpression = updatedExpression.replace("=++", "= ++");
//        } else if(updatedExpression.contains("=--")) {
//            updatedExpression = updatedExpression.replace("=--", "= --");
//        }
//
//        return updatedExpression;
//    }

    private String generateTempVariableName(String prefix) {
        return prefix + ++tempCount;
    }

    private enum IncrementDecrementType {
        POST_PLUS("([a-zA-Z]w*\\+\\+)", true, true),
        PRE_PLUS("(\\+\\+[a-zA-Z]\\w*)", false, true),
        POST_MINUS("([a-zA-Z]w*\\-\\-)", true, false),
        PRE_MINUS("(\\-\\-[a-zA-Z]\\w*)", false, false);

        private Pattern pattern;
        private boolean post;
        private boolean increment;

        IncrementDecrementType(String pattern, boolean post, boolean increment) {
            this.pattern = Pattern.compile(pattern);
            this.post = post;
            this.increment = increment;
        }
    }


    public static void main(String[] args) {
        new AssignmentConverter().convertExpression("x*=i++ +2 * 5", new ExpressionsHandlerImpl<>(new IntegerExpressionEvaluator())).forEach(System.out::println);
    }
}
