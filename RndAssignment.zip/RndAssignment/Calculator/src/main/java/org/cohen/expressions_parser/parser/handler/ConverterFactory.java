package org.cohen.expressions_parser.parser.handler;

public class ConverterFactory {

    public static ExpressionConverter getConverter(String expression) {
        if(expression.contains("=") && expression.chars().filter(c -> c == '=').count() == 1) {
            return new AssignmentConverter();
        } else if(expression.contains("++") || expression.contains("--")) {
            return new IncrementDecrementConverter();
        } else {
            throw new IllegalArgumentException("The following expression doesn't have '=' nor '++' or has multiple '='");
        }

    }

}
