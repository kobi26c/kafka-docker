package org.cohen.expressions_parser.parser.handler;

public interface ExpressionContext<T extends Number> extends ExpressionsHandler<T> {
    void addVariable(String name);
    void addTempVariable(String name);
}
