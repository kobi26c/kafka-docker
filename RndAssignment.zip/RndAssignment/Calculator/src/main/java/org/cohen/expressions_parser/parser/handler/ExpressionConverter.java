package org.cohen.expressions_parser.parser.handler;

import java.util.List;

/**
 * An interface for expressions manipulation - we can get one expressions and convert it to many expressions
 *
 */

public interface ExpressionConverter {
    <T extends Number> List<String> convertExpression(String expression, ExpressionContext<T> context);
}
