package org.cohen.expressions_parser.parser.handler;

import org.cohen.expressions_parser.parser.IntegerExpressionEvaluator;

public class ExpressionHandlerFactory {

    @SuppressWarnings("unchecked")
    public static <T extends Number>  ExpressionsHandler<T> getHandler(Class<T> type) {
        if(type.equals(Integer.class)) {
            return (ExpressionsHandler<T>) new ExpressionsHandlerImpl<>(new IntegerExpressionEvaluator());
        }

        throw new IllegalArgumentException("No implementation for " + type.getName() + " yet.");
    }



}
