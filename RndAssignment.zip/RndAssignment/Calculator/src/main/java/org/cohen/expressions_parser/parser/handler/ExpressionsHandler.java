package org.cohen.expressions_parser.parser.handler;

import java.util.Map;

/**
 * API for external usage
 */
public interface ExpressionsHandler<T extends Number> {
    void addExpression(String expression);
    Map<String, T> getVariables();
}
