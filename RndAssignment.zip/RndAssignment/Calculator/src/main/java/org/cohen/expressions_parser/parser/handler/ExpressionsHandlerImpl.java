package org.cohen.expressions_parser.parser.handler;

import org.cohen.expressions_parser.parser.ExpressionEvaluator;
import org.cohen.expressions_parser.parser.ParserException;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class ExpressionsHandlerImpl<T extends Number> implements ExpressionContext<T> {

    private Map<String, T> variablesMap;
    private Map<String, T> tempVariables;
    private ExpressionEvaluator<T> expressionEvaluator;

    ExpressionsHandlerImpl(ExpressionEvaluator<T> expressionEvaluator) {
        this.expressionEvaluator = expressionEvaluator;
        variablesMap = new HashMap<>();
        tempVariables = new HashMap<>();
    }

    @Override
    public void addVariable(String name) {
        variablesMap.putIfAbsent(name, null);
    }

    @Override
    public void addTempVariable(String name) {
        tempVariables.putIfAbsent(name, null);
    }

    @Override
    public void addExpression(String expression) {
        //We expect the converter to add all variables and temp variables and return expressions that have simple assignment
        List<String> newExpressions = ConverterFactory.getConverter(expression).convertExpression(expression, this);

        for(String currentExpression : newExpressions) {
            String[] variableAndExpression = currentExpression.split("=");
            String variable = variableAndExpression[0].trim();
            T newValue = expressionEvaluator.evaluate(convertVariables(variableAndExpression[1].trim()));
            if(variablesMap.containsKey(variable)) {
                variablesMap.put(variable, newValue);
            } else {
                tempVariables.put(variable, newValue);
            }
        }
    }

    @Override
    public Map<String, T> getVariables() {
        return Collections.unmodifiableMap(variablesMap);
    }

    private String convertVariables(String expression) {
        String newExpression = expression;
        Pattern variablePattern = Pattern.compile("([a-zA-Z]\\w*)");
        Matcher matcher = variablePattern.matcher(newExpression);
        while(matcher.find()) {
            String variable = matcher.group();
            String value;
            if(variablesMap.containsKey(variable)) {
                T paramValue = variablesMap.get(variable);
                if(Objects.isNull(paramValue)) {
                    throw new ParserException("param with name: " + variable + " is used without initializing it");
                }
                value = paramValue.toString();
            } else if(tempVariables.containsKey(variable)) {
                value = tempVariables.get(variable).toString();
            } else {
                throw new IllegalArgumentException("variable: " + variable + " was not defined and was used in expression: " + expression);
            }
            newExpression = matcher.replaceFirst(value);
            matcher = variablePattern.matcher(newExpression);
        }

        return newExpression;
    }

}
