package org.cohen.expressions_parser.parser.handler;

import org.cohen.expressions_parser.parser.ParserException;

import java.util.Collections;
import java.util.List;

public class IncrementDecrementConverter implements ExpressionConverter {
    @Override
    public <T extends Number> List<String> convertExpression(String expression, ExpressionContext<T> context) {
        boolean increment = expression.contains("++");
        String variableName = getVariableName(increment, expression);
        validateExpression(increment, expression, variableName);
        context.addVariable(variableName);
        return Collections.singletonList(createNewExpression(increment, variableName));
    }

    private static void validateExpression(boolean increment, String expression, String variable) {
        String sign = increment ? "++" : "--";
        if(!expression.trim().equals(variable + sign) && !expression.trim().equals(sign + variable)) {
            throw new ParserException("The following expression: " + expression + " is invalid");
        }
    }




    static String createNewExpression(boolean increment, String variableName) {
        return String.format("%s=%s%s1", variableName, variableName, increment ? "+" : "-");
    }

    static String getVariableName(boolean increment, String expression) {
        return expression.replace(increment ? "+" : "-", "").trim();
    }
}
