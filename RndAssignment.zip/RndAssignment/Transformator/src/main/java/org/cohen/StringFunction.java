package org.cohen;

public interface StringFunction {
     String transform(String str);
}
