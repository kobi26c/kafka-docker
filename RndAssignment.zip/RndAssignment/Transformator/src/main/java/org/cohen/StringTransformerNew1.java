package org.cohen;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StringTransformerNew1 {
    private List<String> data = new ArrayList<>();

    public StringTransformerNew1(List<String> startingData) {
        this.data = startingData;
    }

    public List<String> transform(List<StringFunction> functions) throws InterruptedException {
        Stream<String> dataStream = data.parallelStream();
        for(StringFunction function : functions) {
            dataStream = dataStream.map(function::transform);
        }

        data = dataStream.collect(Collectors.toList());
        return data;
    }
}
