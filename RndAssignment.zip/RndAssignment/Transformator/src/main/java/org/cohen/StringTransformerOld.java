package org.cohen;

import java.util.*;

public class StringTransformerOld {

    private List<String> data = new ArrayList<String>();

    public StringTransformerOld(List<String> startingData) {
        this.data = startingData;
    }

    private void forEach(StringFunction function) {
        List<String> newData = new ArrayList<String>();
        for (String str : data) {
            newData.add(function.transform(str));
        }
        data = newData;
    }

    public List<String> transform(List<StringFunction> functions) throws
            InterruptedException {
        List<Thread> threads = new ArrayList<Thread>();
        for (final StringFunction f : functions) {
            threads.add(new Thread(new Runnable() {
                @Override
                public void run() {
                    forEach(f);
                }
            }));

        }
        for (Thread t : threads) {
            t.join();
        }
        return data;
    }


    public static void main(String[] args) throws Exception {
        new Thread().join();
        List<StringFunction> functions = new ArrayList<>();

        functions.add(String::toUpperCase);
//        functions.add(String::toLowerCase);
        functions.add(str -> str + "MM");
        functions.add(str -> "YOYO: " + str);

        List<String> startingData = Arrays.asList("a", "b", "c", "d");



        List<String> transformedOld = new StringTransformerOld(startingData).transform(functions);

        System.out.println(transformedOld);

        List<String> transformedNew = new StringTransformerNew1(startingData).transform(functions);

        System.out.println(transformedNew);
    }
}
